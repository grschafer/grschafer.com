'''
Created on Aug 11, 2011

@author: Beric
'''
import copy
import numpy
import os
import pygame
import random
import sys
import time
from pygame.locals import *
from tetra_graphics_manager import TetraGraphicsManager
from tetra_sprite import TetraSprite
from board import Board

'''
make surface for block dump at the bottom
blit pieces to the surface when they collide at bottom
when rows clear, use transform.chop to cut pieces of block dump image
into a new image and move it down or something
'''


WIDTH = 680
HEIGHT = 880
BOARD = pygame.rect.Rect(40, 40, 400, 800)
score = 0
level = 0
linescleared = 0

def addblock():
    controlled_block = TetraSprite()
    controlled_block.rect.topleft = (BOARD.centerx - 40, BOARD.top)
    return controlled_block

def drawblockpreviews(canvas):
    pieces = map(lambda x: TetraSprite.PIECES[x], TetraSprite.getpreviewpieces())
    btm = 80
    for i in range(0, len(pieces)):
        cur = pygame.transform.scale(pieces[i]['img'], map(lambda x: x/(i+1), pieces[i]['img'].get_size()))
        canvas.blit(cur, (480, btm))
        btm += cur.get_size()[1] + 10

def pix2coord(pos):
    return [x / 40 for x in pos]

def move_block(block, vec):
    block.rect.left += vec[0]
    block.rect.top += vec[1]
    
    collided = board.check_collision(block.array, pix2coord(block.rect.topleft))
    if collided:
        block.rect.left -= vec[0]
        block.rect.top -= vec[1]
        if vec[1] != 0:
            # move controlled_block to blockdump (blit it to the surface?)
            rowsfilled = board.add_block_to_dump(block, block.array, pix2coord(block.rect.topleft))
            global linescleared
            linescleared += rowsfilled
            global score
            score += rowsfilled * rowsfilled * 100
            block = addblock()
            fall_block_group.add(block)
    return block

if __name__ == '__main__':
    pygame.init()
    pygame.key.set_repeat(50, 50)
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    TetraSprite.initpieces()
    myfont = TetraGraphicsManager.load_font("ORATORSTD.OTF", 16)
    pygame.display.set_caption('TetraDrop')
    clock = pygame.time.Clock()
    
    board = Board()
    
    pygame.time.set_timer(USEREVENT + 1, 1000)

    controlled_block = addblock()
#    fall_block_group = pygame.sprite.RenderPlain(controlled_block)
    fall_block_group = pygame.sprite.GroupSingle(controlled_block)
    
    # Game Loop
    while True:
        # event handling
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == KEYDOWN:
                if event.key == K_LEFT:
                    controlled_block = move_block(controlled_block, (-40, 0))
                elif event.key == K_RIGHT:
                    controlled_block = move_block(controlled_block, (40, 0))
                elif event.key == K_UP:
                    controlled_block.rotate()
                    # try to fit block in by bumping to left or right
                    if board.check_collision(controlled_block.array, pix2coord(controlled_block.rect.topleft)):
                        controlled_block.rect.left -= 40
                        if board.check_collision(controlled_block.array, pix2coord(controlled_block.rect.topleft)):
                            controlled_block.rect.left += 80
                            if board.check_collision(controlled_block.array, pix2coord(controlled_block.rect.topleft)):
                                if controlled_block.shape == 'I':
                                    controlled_block.rect.left -= 120
                                    if board.check_collision(controlled_block.array, pix2coord(controlled_block.rect.topleft)):
                                        controlled_block.rect.left += 80
                                        controlled_block.rotate()
                                        controlled_block.rotate()
                                        controlled_block.rotate()
                                else:
                                    controlled_block.rect.left -= 40
                                    controlled_block.rotate()
                                    controlled_block.rotate()
                                    controlled_block.rotate()
                elif event.key == K_DOWN:
                    controlled_block = move_block(controlled_block, (0, 40))
                elif event.key == K_SPACE:
                    refblock = controlled_block
                    while refblock == controlled_block:
                        controlled_block = move_block(controlled_block, (0, 40))
                elif event.key == K_q:
                    pygame.quit()
                    sys.exit()
            elif event.type == USEREVENT + 1:
                controlled_block = move_block(controlled_block, (0, 40))
        
        # handle game logic (loop)
        if linescleared >= level * 5 and level < 9:
            pygame.time.set_timer(USEREVENT + 1, (1000 - level * 100))
            level += 1
        
        
        
        # handle graphics (render)
        screen.blit(board.background, (0, 0))
        # this doesn't actually change until there's a new controlled_block
        # take advantage of this when implementing dirty rect updating?
        drawblockpreviews(screen)
        txt_score = myfont.render(str(score), True, (255,255,255), (0,0,0))
        txt_level = myfont.render(str(level), True, (255,255,255), (0,0,0))
        txt_clears = myfont.render(str(linescleared), True, (255,255,255), (0,0,0))
        screen.blit(txt_score, (480,370))
        screen.blit(txt_level, (480,450))
        screen.blit(txt_clears, (580,450))
        screen.blit(board.blockdump, BOARD.topleft)
        fall_block_group.draw(screen)
        
        # lose condition
        if sum(board.board_array[1]) > 2:
            pygame.time.set_timer(USEREVENT + 1, 0)
            txt_lose = myfont.render("game over", True, (255,255,255), (0,0,0))
            screen.blit(txt_lose, (BOARD.centerx - txt_lose.get_size()[0]/2, BOARD.centery - txt_lose.get_size()[1]/2))
            
        
        # draw the window onto the screen
        pygame.display.update()
        clock.tick(10)

'''
Created on Aug 11, 2011

@author: Greg
'''
from tetra_graphics_manager import TetraGraphicsManager
import numpy
import pygame
import random
from collections import deque
import itertools


class TetraSprite(pygame.sprite.Sprite):

    PIECES = ()
    PIECE_QUEUE = deque()
    
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        piece = self.getpiece()
        self.image = piece['img']
        self.rect = self.image.get_rect()
        self.shape = piece['shape']
        self.offsets = piece['offsets']
        self.array = piece['array']
        self.rotate_count = 0
    
    @staticmethod
    def initpieces():
        '''Loads piece images, other info, and randomization (needs distinct call b/c pygame.display must be initialized first'''
        TetraSprite.PIECES = (
             {'img':TetraGraphicsManager.load_image("blocks.png", pygame.Rect(0, 0, 160, 40), (255, 255, 255)),
              'shape':'I', 'offsets':((-40, 40), (40, -40)), 'array':[[1, 1, 1, 1]]},
             {'img':TetraGraphicsManager.load_image("blocks.png", pygame.Rect(0, 80, 120, 80), (255, 255, 255)),
              'shape':'L', 'offsets':((0, 40), (0, 0), (-40, 0), (40, -40)), 'array':[[1, 1, 1], [1, 0, 0]]},
             {'img':TetraGraphicsManager.load_image("blocks.png", pygame.Rect(0, 160, 120, 80), (255, 255, 255)),
              'shape':'J', 'offsets':((0, 40), (0, 0), (-40, 0), (40, -40)), 'array':[[1, 1, 1], [0, 0, 1]]},
             {'img':TetraGraphicsManager.load_image("blocks.png", pygame.Rect(0, 240, 80, 80), (255, 255, 255)),
              'shape':'O', 'offsets':((0, 0), (0, 0)), 'array':[[1, 1], [1, 1]]},
             {'img':TetraGraphicsManager.load_image("blocks.png", pygame.Rect(0, 320, 120, 80), (255, 255, 255)),
              'shape':'S', 'offsets':((-40, 40), (40, -40)), 'array':[[0, 1, 1], [1, 1, 0]]},
             {'img':TetraGraphicsManager.load_image("blocks.png", pygame.Rect(0, 400, 120, 80), (255, 255, 255)),
              'shape':'Z', 'offsets':((-40, 40), (40, -40)), 'array':[[1, 1, 0], [0, 1, 1]]},
             {'img':TetraGraphicsManager.load_image("blocks.png", pygame.Rect(0, 480, 120, 80), (255, 255, 255)),
              'shape':'T', 'offsets':((0, 40), (0, 0), (-40, 0), (40, -40)), 'array':[[1, 1, 1], [0, 1, 0]]}
        )
        TetraSprite.randomizebag()
        
    
    @staticmethod
    def getpiece():
        piece = TetraSprite.PIECES[TetraSprite.PIECE_QUEUE.popleft()]
        # generate more pieces if # pieces left in queue falls below # prviewed
        if len(TetraSprite.PIECE_QUEUE) <= 4:
            TetraSprite.randomizebag()
        return piece
    
    @staticmethod
    def getpreviewpieces():
        return list(itertools.islice(TetraSprite.PIECE_QUEUE, 0, 5))
    
    @staticmethod
    def randomizebag():
        # generate future bag also so I can show next block previews
        bag = range(len(TetraSprite.PIECES))
        random.shuffle(bag)
        TetraSprite.PIECE_QUEUE.extend(bag)
        print(TetraSprite.PIECE_QUEUE)
    
    def rotate(self):
        '''Rotates this piece 90 degrees counter-clockwise'''
        self.image = pygame.transform.rotate(self.image, -90)
        self.rect.width, self.rect.height = self.rect.height, self.rect.width
        self.rect.centerx -= self.offsets[self.rotate_count][0]
        self.rect.centery -= self.offsets[self.rotate_count][1]
        if self.rotate_count < len(self.offsets) - 1:
            self.rotate_count += 1
        else:
            self.rotate_count = 0
        self.array = numpy.rot90(self.array, 3)
        
